# ServiceNow Email Verifier

This is a small ServiceNow app for email validation. 

* The app includes a table, which stores all the information regarding the validation.
* Business rule to create the validation code.
* Notification to send to user, which need to validate their email
* Scripted REST API for validating the email
* ServicePortal widget, which can be used to validate the users email
